//#include"header.h"
//class Line
//{
//private:
//	int * iPtr;
//
//public:
//	Line()
//	{
//		iPtr = new int;
//		*iPtr = 0;
//	}
//	Line(int len)
//	{
//		iPtr = new int;
//		*iPtr = len;
//	}
//	Line(const Line &obj)
//	{
//		iPtr = new int;
//		*iPtr = *obj.iPtr;
//	}
//	~Line()
//	{
//		delete iPtr;
//	}
//	int getLength()
//	{
//		return *iPtr;
//	}
//	void display()
//	{
//		cout<<"Line of line:"<<*iPtr<<endl;
//	}
//};
//
//int main()
//{
//	Line l1(10);
//
//	Line l2 = l1; // this calls copy constructor
//	return 0;
//}
