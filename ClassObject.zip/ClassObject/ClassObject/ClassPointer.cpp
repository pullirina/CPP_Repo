//#include<iostream>
//using namespace std;
//
//class Box
//{
//	double length,width,height;
//public:
//	Box() // default
//	{
//		length = 0; // writing this-> for memebers is not compulsary
//		width = 0;
//		height = 0;
//	}
//	Box(double l,double w,double h) // parametrised
//	{
//		length = l;
//		width = w;
//		height = h;
//	}
//	Box(Box& obj) // copy
//	{
//		length = obj.length;
//		width = obj.width;
//		height = obj.height;
//	}
//	double volume()
//	{
//		return length*width*height;
//	}
//
//};
//
//int main()
//{
//	Box stackObj(1,2,3);  //stack object
//
//	Box* pBox = NULL; // stack pointer to class Box
//
//	Box* pHeapObj = new Box(2,3,4); // stack pointer to a heap object
//
//	double volume = stackObj.volume(); //6
//
//	//volume = pBox->volume(); //throws runtime error as pBox is null
//
//	pBox = &stackObj;
//
//	volume = pBox->volume();	//6
//
//	volume = pHeapObj->volume(); //24
//
//	pBox = pHeapObj; // As these are pointers to same class
//	
//	volume = pBox->volume(); //24
//	
//	return 0;
//}