//#include<iostream>
//using namespace std;
//
//class Rectangle
//{
//	int height,width;	//member variables
//	int getArea();
//public:
//	void setData(int,int);
//	void displayArea();
//};
//
//void Rectangle::setData(int h,int w)
//{
//	height =h;
//	width = w;
//}
//
//int Rectangle::getArea()
//{
//	return height*width;
//}
//
//void Rectangle::displayArea()
//{
//	cout<<"Area of rectangle is :"<<getArea()<<endl;
//}
//
//int main()
//{
//	Rectangle rStack; // object is created on stack
//	rStack.setData(5,4);
//
//	Rectangle *rHeap = new Rectangle(); //object is created on healp
//	rHeap->setData(2,3);
//
//	rStack.displayArea();
//
//	rHeap->displayArea();
//	
//	//rStack.getArea(); //private function is inaccessible
//
//	return 0;
//}