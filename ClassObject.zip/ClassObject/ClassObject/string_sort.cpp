

//Using string in data type
#include<iostream>
#include<string>
#include<vector>
using namespace std;
#define N 6
int main()
{
	
	string colour[N] = { "Blue", "Red","Orange","Yellow","Black","Ash" }; 
	//Ash Black Blue Orange red yellow
	string temp = "";
	
	cout<<"*****************Before sorting:"<<endl;
	for(int i =0; i < N;i ++)
		cout<<colour[i]<<endl;
	
	for(int i = 0; i < N; i++)
	{
		for(int j = i+1; j < N; j++)
		{
			if(colour[i] > colour[j])
			{ 
				temp = colour[i];
				colour[i] = colour[j];
				colour[j] = temp;
			}
		}
	}
	cout<<"*****************After sorting:"<<endl;

	for(int i =0; i < N;i ++)
		cout<<colour[i]<<endl; 
	vector<string> cities;

	return 0;
}