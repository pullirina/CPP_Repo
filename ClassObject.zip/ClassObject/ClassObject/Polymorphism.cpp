///*
//Polymorphism-
//The word polymorphism means having many forms. 
//Typically,polymorphism occurs when there is a hierarchy of classes and they are related by inheritance.
//*/
//#include"header.h"
//
//class Shape
//{
//public:
//	double width,height;
//
//	Shape(double w,double h)
//	{
//		width = w; height = h;
//	}
//
//	virtual double area() //double area()
//	{
//		cout<<"Shape::area()"<<endl;
//		return 0;
//	}
//};
//
//class Box : public Shape
//{
//public:
//	double length;
//	Box(double w,double h,double l):Shape(w,h)
//	{
//		length = l;
//	}
//
//	double area()
//	{
//		return width*length*height;
//	}
//};
//int main()
//{
//	Shape *ptr;
//	Box b1(2,3,4);
//
//	ptr = &b1;
//
//	cout<<"Area of box is :"<<ptr->area()<<endl;
//
//	return 0;
//}