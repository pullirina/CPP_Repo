///*
//Multiple Inheritance
//Multiple Inheritance is a feature of C++ where a class can inherit from more than one class.
//
//	class B
//			>>>>>>>>>>>>> class A
//	Class C
//
//	(Base c's)    (Derived class)
//
//Syntax:
//class subclass_name : access_mode base_class1, access_mode base_class2, ....
//
//*/
//#include"header.h"
//
//class Vehicle
//{
//public:
//	Vehicle()
//	{
//		cout<<"This is a vehicle"<<endl;
//	}
//};
//
//class FourWheeler
//{
//public:
//	FourWheeler()
//	{
//		cout<<"This is a FourWheeler"<<endl;
//	}
//};
//
//
//class Car : public Vehicle, public FourWheeler
//{
//public:
//	Car()
//	{
//		cout<<"This is a Car"<<endl;
//	}
//};
//
//int main()
//{
//	Car cObj;
//	return 0;
//}