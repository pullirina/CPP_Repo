/*
C++ has access to its own address through an important pointer called this pointer. 
The this pointer is an implicit parameter to all member functions. 
Therefore, inside a member function, this may be used to refer to the invoking object
*/

//#include<iostream>
//using namespace std;
//
//class Box
//{
//	double length,width,height;
//public:
//	Box()
//	{
//		this->length = 0; // writing this-> for memebers is not compulsary
//		width = 0;
//		height = 0;
//	}
//	Box(double l,double w,double h)
//	{
//		length = l;
//		this->width = w;
//		height = h;
//	}
//	Box(Box& obj)
//	{
//		length = obj.length;
//		width = obj.width;
//		height = obj.height;
//	}
//
//	double volume()
//	{
//		return length*width*height;
//	}
//
//	int IsVolumeSame(Box obj)
//	{
//		if(this->volume() == obj.volume())
//			return 1;
//		else
//			return 0;
//	}
//};
//
//int main()
//{
//	Box b1(2,3,4);
//	Box b2(4,5,6);
//
//	if(b1.IsVolumeSame(b2))
//		cout<<"Volumes are same"<<endl;
//	else
//		cout<<"Volumes are not same"<<endl;
//
//	return 0;
//}