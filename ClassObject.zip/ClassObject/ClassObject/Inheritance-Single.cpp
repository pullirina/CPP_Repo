///*
//Single inheritance:
//In single inheritance, a class is allowed to inherit from only one class.
//		
//		class A ---> class B
//		(Base)		 (Derived)
//*/
//#include<iostream>
//using namespace std;
//
//class Vehicle
//{
//public:
//	Vehicle()
//	{
//		cout<<"This is a vehicle"<<endl;
//	}
//};
//
//class Car : public Vehicle
//{
//public:
//	Car()
//	{
//		cout<<"This is a car"<<endl;
//	}
//};
//
//int main()
//{
//	Car cObj; // Object gets created starting from its base class properties
//	return 0;
//}