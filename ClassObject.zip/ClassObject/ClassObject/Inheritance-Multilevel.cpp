//#include"header.h"
///*
//Multi-level inheritance
//In this type of inheritance, a derived class is created from another derived class.
//
//		class C ----__-> class B ------> Class A
//		(Base 1)		(base 2)			(Derived 2)
//						(Derived 1)
//*/
//
//class Vehicle
//{
//public:
//	Vehicle()
//	{
//		cout<<"This is a vehicle"<<endl;
//	}
//};
//
//class FourWheeler : public Vehicle
//{
//public:
//	FourWheeler()
//	{
//		cout<<"This is a FourWheeler"<<endl;
//	}
//};
//
//class Car : public FourWheeler
//{
//public:
//	Car()
//	{
//		cout<<"This is a Car"<<endl;
//	}
//};
//
//int main()
//{
//	Car cObj;
//	return 0;
//}