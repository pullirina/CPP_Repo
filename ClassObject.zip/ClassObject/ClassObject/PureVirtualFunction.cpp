/*
Pure virtual function-
Sometimes implementation of all function cannot be provided in a base class because we don�t know the implementation. 
Such a class is called abstract class. 
For example, let Shape be a base class. We cannot provide implementation of function area() in Shape, 
but we know every derived class must have implementation of area(). like Rectangle ,Triangle etc.

A pure virtual function is declared by assigning 0 in declaration.
*/

#include"header.h"

class Shape
{
public:
	virtual void area() = 0; //pure virtual functioon
};

class Rectangle : public Shape
{
public:
	double width,height;

	Rectangle()
	{
		width = height = 0;
	}
	Rectangle(double w,double h)
	{
		width = w;
		height = h;
	}
	void area()
	{
		cout<<"Area of rectangle:"<<width*height<<endl;
	}
};

class Triangle : public Shape
{
public:
	double base,height;

	Triangle()
	{
		base = height = 0;
	}
	Triangle(double b,double h)
	{
		base = b;
		height = h;
	}
	void area()
	{
		cout<<"Area of rectangle:"<<0.5*base*height<<endl;
	}
};

int main()
{
	Rectangle rect(2,3);
	Shape *ptr = &rect;

	ptr->area();

	return 0;
}