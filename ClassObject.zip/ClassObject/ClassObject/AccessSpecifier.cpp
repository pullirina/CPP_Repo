/*
C++ Class Access Modifiers

1. Public
A public member is accessible from anywhere outside the class as well as within a program. 
You can set and get the value of public variables without any member function

2. Private
A private member variable or function cannot be accessed, or even viewed from outside the class. 
Only the class and friend functions can access private members.

3. Protected
A protected member variable or function is very similar to a private member but 
it provided one additional benefit that they can be accessed in child classes which are called derived classes.
*/

#include<iostream>
using namespace std;

//class Point
//{
//private:
//	int x,y;
//public:
//	int getX()
//	{ 
//		return x;
//	}
//	void setX(int ix)
//	{
//		x = ix;
//	}
//	int getY()
//	{ 
//		return y;
//	}
//	void setY(int iy)
//	{
//		y = iy;
//	}
//};
//
//int main()
//{
//	Point p;
//	p.setX(3);
//	p.setY(5);
//
//	int px = p.getX();
//	int py = p.getY();
//	
//	return 0;
//}
//-----------------------------------------------------------------------------------
//class Point
//{
//public:
//	int x,y;
//
//	void display() // x and y are access within and outside the class
//	{
//		cout<<"X:"<<x<<"\t"<<"Y:"<<y<<endl;
//	}
//};
//
//int main()
//{
//	Point p;
//	p.x = 3;
//	p.y = 4;
//
//	p.display();
//
//	return 0;
//};
//-----------------------------------------------------------------------------------
//class Point
//{
//protected:
//	int x,y;
//
//public:
//
//};
//
//class CoPoint : private Point
//{
//	//Protected members of base class becomes private in derived class 
//public:
//	void setX(int ix)
//	{
//		x = ix;
//	}
//	
//	void setY(int iy)
//	{
//		y = iy;
//	} 
//
//	void display()
//	{
//		cout<<"X:"<<x<<"\t"<<"Y:"<<y<<endl;
//	}
//};
//int main()
//{
//	CoPoint cp;
//	cp.setX(4);
//	cp.setY(6);
//
//	cp.display();
//
//	return 0;
//}