///*
//To resolve this ambiguity when class A is inherited in both class B and class C, it is declared as virtual base class by placing a keyword virtual.
//
//The diamond problem
//The diamond problem occurs when two superclasses of a class have a common base class.
//*/
//
//#include<iostream>
//using namespace std;
//
//class A
//{
//public:
//	A()
//	{
//		cout<<"A::A()";
//	}
//};
//
//class B : virtual public A
//{
//public:
//	B()
//	{
//		cout<<"B::B()";
//	}
//};
//
//class C : virtual public A
//{
//public:
//	C()
//	{
//		cout<<"C::C()";
//	}
//};
//
//class D : public B, public C
//{
//public:
//	D()
//	{
//		cout<<"D::D()";
//	}
//};
//
//
//int main()
//{
//	D obj;
//
//	return 0;
//}
//
