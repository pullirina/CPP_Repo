///*
//The subscript operator [] is normally used to access array elements.
//This operator can be overloaded to enhance the existing functionality of C++ arrays.
//*/
//#include"header.h"
//const int SIZE = 5;
//
//class safeArray
//{
//	int arr[SIZE];
//public:
//	safeArray()
//	{
//		for(int i = 0;i< SIZE;i++)
//		{
//			arr[i] = i+1;
//		}
//	}
//
//	int& operator[](int i)
//	{
//		if(i>SIZE)
//		{
//			cout<<"index out of bound"<<endl;
//			return arr[SIZE-1];
//		}
//		return arr[i];
//	}
//};
//int main()
//{
//	safeArray a;
//
//	cout<<a[2]<<endl; //calls operator overloaded [] function
//	cout<<a[6]<<endl;
//	return 0;
//}