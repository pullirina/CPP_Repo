//#include<iostream>
//using namespace std;
//
//class Triangle
//{
//	int base;
//	int height;
//
//public:
//	Triangle() // default consructor
//	{
//		base = height = 0;
//	}
//
//	Triangle(int b,int h) // parametrised consructor
//	{
//		base = b;
//		height = h;
//	}
//
//	Triangle(Triangle& obj)
//	{
//		base = obj.base;
//		height = obj.height;
//	}
//
//	double getArea()
//	{
//		return 0.5 * base * height;
//	}
//
//	void display()
//	{
//		cout<<"base:"<<base<<endl;
//		cout<<"height:"<<height<<endl;
//	}
//
//	~Triangle()
//	{
//		cout<<"D called"<<endl;
//	}
//};
//
//int main()
//{
//	//Triangle t1,t2(4,4);
//	//Triangle t3(t2); //copy constructor gets called
//	//Triangle t4 = t2; //copy constructor gets called
//	//t1 = t2; //default =operator gets called
//
//	Triangle *tP = new Triangle(4,6);
//	tP->display();
//
//	delete tP; // we should always call  delete when we do new 
//
//	return 0;
//}