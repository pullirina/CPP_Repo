///*
//Polymorphism-
//The word polymorphism means having many forms. 
//Typically,polymorphism occurs when there is a hierarchy of classes and they are related by inheritance.
//*/
//#include"header.h"
//
//class vehicle
//{
//	int x = 0;
//public:
//	void f()
//	{
//		x++;
//	}
//};
//
//int main()
//{
//	//vehicle v* = new vehicle;
//	return 0;
//}