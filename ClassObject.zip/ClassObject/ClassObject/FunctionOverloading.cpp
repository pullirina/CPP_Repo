///*
//Function overloading-
//Two or more functions having same name but different argument(s) are known as overloaded functions.
//The definition of the function must differ from each other by,
//1.The types of arguments in the argument list
//2.The number of arguments in the argument list
//
//You cannot overload function declarations that differ only by return type.
//*/
//#include"header.h"
//
//class printData
//{
//public:
//	void print(int i)
//	{
//		cout<<"printing integer:"<<i<<endl;
//	}
//	void print(double d)
//	{
//		cout<<"printing double:"<<d<<endl;
//	}
//	void print(char* s)
//	{
//		cout<<"printing char*:"<<s<<endl;
//	}
//};
//
//int main()
//{
//	int i = 50;
//	double d = 1.2;
//	char* s = "AmRina";
//
//	printData obj;
//
//	obj.print(i);
//	obj.print(d);
//	obj.print(s);
//
//	return 0;
//}