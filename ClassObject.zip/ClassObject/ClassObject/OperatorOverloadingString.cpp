///*
//Operator Overloading
//In C++, we can make operators to work for user defined classes. This means C++ has the ability 
//to provide the operators with a special meaning for a data type, this ability is known as operator overloading.
//For example, we can overload an operator �+� in a class like String so that we can concatenate two strings by just using +.
//Other example classes where arithmetic operators may be overloaded are Complex Number, Fractional Number, Big Integer, etc.
//
//syntax
//class_name operator+ (Class_name obj)
//*/
//
//#include"header.h"
//
//class MyString
//{
//	char str[100];
//
//public:
//	MyString()
//	{
//		strcpy(this->str,"");
//	}
//
//	MyString(char s[])
//	{
//		strcpy(this->str,s);
//	}
//
//	MyString operator+(MyString &SObj) 
//    {
//		MyString retObj;
//
//		strcat(retObj.str,this->str);
//		
//		strcat(retObj.str,SObj.str);
//
//		return retObj;
//	}
//};
//
//int main()
//{
//	char s1[] = "Am";
//	char s2[] = "Rina";
//
//	MyString s1Obj(s1);
//	MyString s2Obj(s2);
//	MyString s3Obj;
//
//	s3Obj = s1Obj + s2Obj; // we can overload the opertor for user defined datatype like Mystring
//
//	return 0;
//}