/*
1. Static variables are initialized only once, at the start of the execution. 
2. These variables will be initialized first, before the initialization of any instance variables. 
3. A single copy to be shared by all instances of the class. 
4. A static variable can be accessed directly by the class name and doesn't need any object.
*/
//#include<iostream>
//using namespace std;
//
//class Box
//{
//	double length,width,height;
//public:
//	static int count;
//	Box()
//	{
//		length = width = height = 0;
//		
//		count++;
//	}
//
//	Box(double l,double w,double h)
//	{
//		length = l;
//		width = w;
//		height = h;
//
//		count++;
//	}
//	Box(Box& obj)
//	{
//		length = obj.length;
//		width = obj.width;
//		height = obj.height;
//
//		count++;
//	}
//
//	static int getObjectCount() // static member functions only access static member variables
//	{
//		return count;
//	}
//};
////initialise the static variable
//int Box::count = 0;
//
//int main()
//{
//	Box b1;
//
//	Box b2(1,2,3);
//
//	Box b3(3,4,5);
//
//	cout<<"Object count:"<<Box::getObjectCount(); // classname::staticMberFun(); // no object is req to call static mem function
//	return 0;
//};