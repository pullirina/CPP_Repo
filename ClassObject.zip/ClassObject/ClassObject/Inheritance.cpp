﻿///*
//Inheritance: The capability of a class to derive properties and characteristics from another class is called Inheritance.
//This also provides an opportunity to reuse the code functionality and fast implementation time.
//When creating a class, instead of writing completely new data members and member functions, 
//the programmer can designate that the new class should inherit the members of an existing class.
//This existing class is called the base class, and the new class is referred to as the derived class.
//syntax:
//class derived-class : access-specifier base-class
//
//Access Control and Inheritance
//A derived class can access all the non-private members of its base class. Thus base-class members that should not be accessible to the member functions of derived classes should be declared private in the base class.
//
//We can summarize the different access types according to - who can access them in the following way −
//
//Access			  public  protected	private
//----------------------------------------------
//Same class			yes		yes		  yes
//Derived classes		yes		yes		  no
//Outside classes		yes		no		  no
//
//A derived class inherits all base class methods with the following exceptions −
//
//1.Constructors, destructors and copy constructors of the base class.
//2.Overloaded operators of the base class.
//3.The friend functions of the base class.
//*/
//#include<iostream>
//using namespace std;
//
//class Shape
//{
//protected:
//	double height,width;
//public:
//	void setHeight(double h)
//	{
//		height = h;
//	}
//	void setWidth(double w)
//	{
//		width = w;
//	}
//};
//
//class Rectangle : public Shape
//{
//public:
//	double getRectangleArea()
//	{
//		return height * width;
//	}
//};
//
//int main()
//{
//	Rectangle rect;
//	rect.setHeight(4);
//	rect.setWidth(5);
//
//	double area = rect.getRectangleArea();
//	cout<<"Area of rect:"<<area<<endl;
//
//	return 0;
//}