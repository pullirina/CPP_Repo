///*
//Hierarchical Inheritance:
//In this type of inheritance, more than one sub class is inherited from a single base class.
//
//			Class A
//			   |
//			   |
//			   X
//	Class B			Class C
//
//Syntax:
//
//Class derived class1 : public base
//
//class derived class2 : public base
//	
//*/
//#include"header.h"
//
//class Vehicle
//{
//public:
//	Vehicle()
//	{
//		cout<<"This is a vehicle"<<endl;
//	}
//};
//
//class Car : public Vehicle
//{
//public:
//	Car()
//	{
//		cout<<"This is a car"<<endl;
//	}
//};
//
//class Bus : public Vehicle
//{
//public:
//	Bus()
//	{
//		cout<<"This is a bus"<<endl;
//	}
//};
//
//int main()
//{
//	Car cObj;
//	Bus bObj;
//	return 0;
//}