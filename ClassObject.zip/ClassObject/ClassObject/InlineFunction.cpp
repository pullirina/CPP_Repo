/*
Inline function
If a function is inline, the compiler places a copy of the code of that function at each point 
where the function is called at compile time.
*/
//#include<iostream>
//using namespace std;
//
//inline int Max(int a,int b)
//{
//	return (a>b) ? a : b;
//}
//
//int main()
//{
//	int x,y;
//	cout<<"Enter two number to find greatest:"<<endl;
//	cin>>x>>y;
//
//	int large = Max(x,y); //defination of max function gets replaced at the place of call
//
//	cout<<"\n The greatest number is "<<large;
//	return 0;
//}