/*===================
OOPs Concepts:
Class
Object

Abstraction
Encapsulation
Inheritence
Polymorphism

Dynamic Binding
====================
Class:
It is a user defined data type, which holds its own data members and member functions, which can be accessed and used by creating an instance of that class. 
A class is like a blueprint for an object.
For Example: We had a class named Employee and Project.
The class employee has a properties as EmployeeID, EmpName etc.

Object:
An Object is an instance of a Class. 
When a class is defined, no memory is allocated but when it is instantiated memory is allocated.
For Example: When a new employee joins organisation. We register him/her in EmPortal. We initialise Employee object. 

Abstraction:
Abstraction means displaying only essential information and hiding the details. 
Data abstraction refers to providing only essential information about the data to the outside world, hiding the background details or implementation.
Consider a real-life example of a man driving a car. 
The man only knows that pressing the accelerators will increase the speed of the car or applying brakes will stop the car but he does not know about how on pressing accelerator the speed is actually increasing, he does not know about the inner mechanism of the car.

Encapsulation:
Encapsulation is defined as binding together the data and the functions that manipulate them.
Example: Capsule. Basically, capsule encapsulate several combinations of medicine.

Polymorphism: The word polymorphism means having many forms. 
Example:
A person at the same time can have different characteristic. 
Like a man at the same time is a father, a husband, an employee. 
So the same person posses different behaviour in different situations. This is called polymorphism.

Inheritance:
The capability of a class to derive properties and characteristics from another class is called Inheritance.
Inheritance supports the concept of �reusability�, 
i.e. when we want to create a new class and there is already a class that includes some of the code that we want,we can derive our new class from the existing class. By doing this, we are reusing the fields and methods of the existing class.

Dynamic Binding: Dynamic binding is determining the method to invoke at runtime instead of at compile time.
C++ has virtual functions to support this.
*/