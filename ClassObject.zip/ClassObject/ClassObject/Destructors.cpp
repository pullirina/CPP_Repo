// C++ destructors are used to de-allocate the memory that has been allocated for the object by the constructor.
// destructor gets called In reverse order of construction: First constructed, last destructed.

#include<iostream>
using namespace std;

class Point
{
public:
	int x,y;

	Point(int ix,int iy)
	{
		x = ix; y = iy;
	}
};

class Line
{
	Point* p1;
	Point* p2;
public:
	Line() // default
	{
		p1 = new Point(0,0);
		p2 = new Point(0,0);
	}
	Line(int x1,int y1,int x2,int y2) //parameterised
	{
		p1 = new Point(x1,y1);
		p2 = new Point(x2,y2);
	}
	Line(Point& st,Point& ed) // copy
	{
		p1 = new Point(st.x,st.y);
		p2 = new Point(ed.x,ed.y);
	}

	~Line()
	{
		delete p1;
		p1 = NULL;

		delete p2;
		p2 = NULL;
	}

	void display()
	{
		cout<<"Line co-ordinates:"<<endl<<"x1 "<<p1->x<<"	y1 "<<p1->y<<endl<<"x2 "<<p2->x<<"	y2 "<<p2->y<<endl;
	}

};

int main()
{
	Point p1(2,3);
	Point p2(6,7);

	/*Line line(p1,p2);
	line.display();*/

	/*Line *pLine = new Line(p1,p2);
	pLine->display();

	delete pLine;
	pLine = NULL;*/

	Line l(2,3,4,5);
	Line *pL = NULL; //stack pointer

	pL = &l;

	//delete pL; we should not call delete for a stack pointer

	return 0;
}

