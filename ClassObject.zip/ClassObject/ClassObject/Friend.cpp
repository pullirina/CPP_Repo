/*
Friend function:
A friend function of a class is defined outside that class' scope 
but it has the right to access all private and protected members of the class. 
Even though the prototypes for friend functions appear in the class definition, friends are not member functions.
*/

//#include<iostream>
//#include<string.h>
//using namespace std;
//
//class Person
//{
//	int age;
//public:
//	char* name;
//
//	friend void displayPerson(Person &Obj); // global friend who can access private and public memebers outside the class.s
//	void setAge(int iAge);
//	
//};
//
//void Person::setAge(int iAge)
//{
//	age = iAge;
//}
//
//void displayPerson(Person &obj)
//{
//	cout<<"Person data:"<<endl;
//	puts(obj.name);
//	cout<<obj.age<<endl;
//}
//
//int main()
//{
//	Person pObj;
//	pObj.name = "Rina";
//	pObj.setAge(28);
//
//	displayPerson(pObj); //call to global friend function
//	friend function
//	return 0;
//}