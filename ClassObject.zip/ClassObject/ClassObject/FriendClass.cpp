///*
//Friend class
//A friend class is a class that can access the private and protected members of a another class in which it is declared as friend. 
//This is needed when we want to allow a particular class to access the private and protected members of a class.
//*/
//#include<iostream>
//using namespace std;
//
//class ABC
//{
//private:
//	int n;
//protected:
//	double d;
//public:
//	ABC(int x,double y)
//	{
//		n = x; d = y;
//	}
//	friend class XYZ;
//};
//
//class XYZ //class XYZ can access memebers of ABC.
//{
//public:
//	void display(ABC obj)
//	{
//		cout<<"n:"<<obj.n<<"\t"<<"d:"<<obj.d<<endl;
//	}
//};
//
//int main()
//{
//	XYZ obj1;
//	ABC obj2(2,1.2);
//
//	obj1.display(obj2);
//
//	return 0;
//}
