/*
Templates allows you to write generic programs. 
In simple terms, you can create a single function or a class to work with different data types using templates.

Templates are often used in larger codebase for the purpose of code reusability and flexibility of the programs.

The concept of templates can be used in two different ways:

Function Templates:
Function templates are special functions that can operate with generic types. This allows us to create a function template whose functionality can be adapted to more than one type or class without repeating the entire code for each type.

Class Templates:
Like function templates, you can also create class templates for generic class operations.
Sometimes, you need a class implementation that is same for all classes, only the data types used are different.
*/
#include<iostream>
using namespace std;

template<typename Type>
class calculator
{
	Type t1, t2;
public:
	calculator(Type a, Type b)
	{
		t1 = a;
		t2 = b;
	}

	void print()
	{
		cout<<endl<<"First operand:"<<t1<<" and Second operand:"<<t2<<endl;
		cout<<"Addition:"<<add()<<endl;
		cout<<"Substraction:"<<sub()<<endl;
		cout<<"Division:"<<div()<<endl;
		cout<<"Multiplication:"<<mult()<<endl;
	}

	Type add() { return t1 + t2;}

	Type sub() { return t1 - t2;}

	Type div() { return t1 / t2;}

	Type mult() { return t1 * t2;}
};

//Type GetMax(Type a, Type b)
//{
//	return a > b ? a : b;
//}

int main()
{
	/*cout<<GetMax(2,3)<<endl;
	cout<<GetMax('b','a')<<endl;
	*/
	calculator<int> c1(8,4);
	calculator<double> c2(12.2,8.8);

	c1.print();
	c2.print();

	return 0;
}

